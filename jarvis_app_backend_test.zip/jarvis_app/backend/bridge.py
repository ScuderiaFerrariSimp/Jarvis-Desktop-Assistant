"""
Bridge — the QObject exposed to JavaScript via QWebChannel.

This is what ui/orb.html's composer calls into (window.bridge.send_message)
instead of the old fake setTimeout stub.
"""

from PySide6.QtCore import QObject, Slot, Signal

from .ai_manager import AIManager


class Bridge(QObject):
    # Emitted when a reply is ready; main.py connects this to push the
    # text into the transcript panel and reset the orb to idle.
    reply_ready = Signal(str)
    error_occurred = Signal(str)

    def __init__(self, ai_manager: AIManager | None = None):
        super().__init__()
        self.ai_manager = ai_manager or AIManager()

    @Slot(str)
    def send_message(self, text: str) -> None:
        """Called from JS when the user submits the composer."""
        try:
            reply = self.ai_manager.reply(text)
            self.reply_ready.emit(reply)
        except Exception as exc:  # noqa: BLE001 — surface any failure to the UI
            self.error_occurred.emit(str(exc))
