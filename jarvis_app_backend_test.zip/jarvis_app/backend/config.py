"""
Config loading — reads API keys and settings from a local .env file.

Never commit .env to git. .env.example shows the expected shape.
"""

from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv
import os

# Load .env from the project root (one level up from backend/)
ENV_PATH = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=ENV_PATH)


@dataclass
class Settings:
    anthropic_api_key: str | None = os.getenv("ANTHROPIC_API_KEY")
    default_model: str = os.getenv("JARVIS_MODEL", "claude-sonnet-4-6")


settings = Settings()
