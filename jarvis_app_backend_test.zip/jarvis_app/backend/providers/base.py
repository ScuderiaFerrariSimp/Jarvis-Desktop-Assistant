"""
Provider abstraction — every AI backend (cloud or local) implements this
same interface, so the AI Manager (and later, an intelligent router) can
swap between them without the rest of the app knowing the difference.

Per Rules.md: "Provider abstraction" is a stated requirement, not optional.
"""

from abc import ABC, abstractmethod


class Provider(ABC):
    """Common interface every AI backend must implement."""

    name: str = "unnamed-provider"

    @abstractmethod
    def reply(self, message: str) -> str:
        """Send a message, return the assistant's text reply.

        Kept synchronous and single-shot for Phase 1 testing simplicity.
        Rules.md calls for "async-first" — this is the one deliberate
        exception, since it's a throwaway test backend. Swap for an
        async streaming version when real providers get wired in.
        """
        raise NotImplementedError
