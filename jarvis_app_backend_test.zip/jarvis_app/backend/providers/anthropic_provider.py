"""
Anthropic provider — talks to Claude via the official SDK.

Requires ANTHROPIC_API_KEY to be set in .env.
"""

from anthropic import Anthropic

from .base import Provider
from ..config import settings


class AnthropicProvider(Provider):
    name = "anthropic"

    def __init__(self, model: str | None = None):
        if not settings.anthropic_api_key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Add it to your .env file "
                "(see .env.example)."
            )
        self.client = Anthropic(api_key=settings.anthropic_api_key)
        self.model = model or settings.default_model

    def reply(self, message: str) -> str:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": message}],
        )
        # response.content is a list of blocks; Phase 1 only handles plain text
        text_blocks = [block.text for block in response.content if block.type == "text"]
        return "\n".join(text_blocks) if text_blocks else "(no text response)"
