"""
AI Manager — Phase 1 version.

Right now this just wraps a single provider. Later (per Phases.md Phase 5:
"AI Manager & benchmarking") this becomes the router that picks local vs
cloud per-request. Keeping it as its own class now means nothing above it
(the bridge, the UI) has to change when that logic gets smarter.
"""

from .providers import Provider, AnthropicProvider


class AIManager:
    def __init__(self, provider: Provider | None = None):
        self.provider = provider or AnthropicProvider()

    def reply(self, message: str) -> str:
        return self.provider.reply(message)
